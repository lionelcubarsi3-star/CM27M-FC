const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: Number(process.env.PORT || 8787) });
const rooms = new Map();
function send(ws, data) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); }
function safeRoom(v) { return String(v || 'CM27-FRIENDS').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 24) || 'CM27-FRIENDS'; }
function roomPeers(room) { return [...(rooms.get(room) || [])].filter(p => p.readyState === WebSocket.OPEN); }
wss.on('connection', ws => {
  ws.on('message', raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return send(ws,{type:'error',message:'رسالة غير صالحة'}); }
    if (msg.type === 'create' || msg.type === 'join') {
      const room = safeRoom(msg.room); const peers = roomPeers(room);
      if (msg.type === 'create' && peers.length) return send(ws,{type:'error',message:'الغرفة موجودة بالفعل، جرّب الانضمام إليها'});
      if (msg.type === 'join' && !peers.length) return send(ws,{type:'error',message:'الغرفة غير موجودة. أنشئها أولاً على جهاز آخر'});
      if (!rooms.has(room)) rooms.set(room,new Set());
      ws.room = room; ws.playerName = String(msg.name || 'CM27 Player').slice(0,22); rooms.get(room).add(ws);
      const all = roomPeers(room); send(ws,{type:'room',room,players:all.length});
      for (const peer of all) if (peer !== ws) { send(peer,{type:'peer',room,players:all.length,name:ws.playerName}); send(ws,{type:'peer',room,players:all.length,name:peer.playerName}); }
      return;
    }
    // Small relay channel for future match-state synchronization; no authoritative game simulation yet.
    if (msg.type === 'relay' && ws.room) {
      const payload = JSON.stringify({type:'relay',from:ws.playerName,data:msg.data});
      for (const peer of roomPeers(ws.room)) if (peer !== ws && peer.readyState === WebSocket.OPEN) peer.send(payload);
    }
  });
  ws.on('close', () => { if (!ws.room || !rooms.has(ws.room)) return; const set=rooms.get(ws.room); set.delete(ws); for (const peer of set) send(peer,{type:'status',message:'لاعب غادر الغرفة'}); if (!set.size) rooms.delete(ws.room); else for (const peer of set) send(peer,{type:'room',room:ws.room,players:set.size}); });
});
wss.on('listening',()=>console.log('CM27 multiplayer signaling server listening on port '+(process.env.PORT||8787)));
